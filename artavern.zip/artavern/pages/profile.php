<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/profile.php';
require_once __DIR__ . '/../includes/posts.php';

$username = trim($_GET['u'] ?? '');
if (!$username) { header('Location: '.SITE_URL.'/index.php'); exit; }

$profile = get_profile($username);
if (!$profile) { http_response_code(404); die('User not found.'); }

$me       = current_user();
$followers = get_follower_count($profile['id']);
$following = get_following_count($profile['id']);
$am_following = $me ? is_following((int)$me['id'], (int)$profile['id']) : false;
$user_posts   = get_user_posts($profile['id']);
$portfolio    = get_portfolio($profile['id']);

$__title = h($profile['display_name']) . ' — ARTavern';
$__page  = 'profile';

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Banner -->
<div class="profile-banner">
  <?php if ($profile['banner_path']): ?>
    <img src="<?= h(UPLOAD_URL.$profile['banner_path']) ?>" alt="banner">
  <?php endif; ?>
</div>

<!-- Profile info -->
<div class="profile-info-row">
  <div class="profile-actions">
    <?php if ($me && $me['id'] == $profile['id']): ?>
      <a href="<?= SITE_URL ?>/pages/settings.php" class="btn btn-ghost btn-sm">Edit Profile</a>
    <?php elseif ($me): ?>
      <button class="btn btn-outline btn-sm follow-btn <?= $am_following?'following':'' ?>"
        onclick="toggleFollow(this,<?= $profile['id'] ?>)">
        <?= $am_following ? 'Following' : 'Follow' ?>
      </button>
      <a href="<?= SITE_URL ?>/pages/messages.php?to=<?= h($profile['username']) ?>"
         class="btn btn-ghost btn-sm">Message</a>
    <?php else: ?>
      <button class="btn btn-primary btn-sm" onclick="openModal('login')">Follow</button>
    <?php endif; ?>
  </div>

  <div class="profile-avatar-large">
    <?php if ($profile['avatar_path']): ?>
      <img src="<?= h(UPLOAD_URL.$profile['avatar_path']) ?>" alt="">
    <?php else: ?>
      <?= strtoupper(substr($profile['display_name'],0,2)) ?>
    <?php endif; ?>
  </div>

  <div class="profile-display-name"><?= h($profile['display_name']) ?></div>
  <div class="profile-handle">@<?= h($profile['username']) ?>
    <?php if ($profile['role'] === 'admin'): ?>
      <span class="chip chip-source" style="margin-left:6px;">Admin</span>
    <?php endif; ?>
    <?php if ($profile['commission_open']): ?>
      <span class="chip chip-medium" style="margin-left:6px;">Open for Commissions</span>
    <?php endif; ?>
  </div>

  <?php if ($profile['bio']): ?>
    <p class="profile-bio"><?= nl2br(h($profile['bio'])) ?></p>
  <?php endif; ?>

  <?php if ($profile['art_styles']): ?>
  <div class="profile-style-chips">
    <?php foreach (explode(',', $profile['art_styles']) as $s): ?>
      <span class="chip chip-medium"><?= h(trim($s)) ?></span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <div class="profile-stats">
    <div><span><?= number_format($followers) ?></span> Followers</div>
    <div><span><?= number_format($following) ?></span> Following</div>
    <div><span><?= number_format(count($user_posts)) ?></span> Posts</div>
  </div>
</div>

<!-- Profile tabs -->
<div class="feed-tabs">
  <div class="feed-tab active" id="tabPosts" onclick="showProfileTab('posts')">Posts</div>
  <div class="feed-tab" id="tabPortfolio" onclick="showProfileTab('portfolio')">Portfolio</div>
</div>

<!-- Posts -->
<div id="profilePosts">
<?php foreach ($user_posts as $post): ?>
<div class="post-card">
  <div class="post-header">
    <div class="post-avatar" style="background:linear-gradient(135deg,var(--accent),#7a4820);">
      <?= strtoupper(substr($profile['display_name'],0,2)) ?>
    </div>
    <div>
      <div class="post-meta-name"><?= h($profile['display_name']) ?></div>
      <div class="post-meta-handle">@<?= h($profile['username']) ?></div>
    </div>
    <div class="post-meta-time"><?= time_ago($post['created_at']) ?></div>
  </div>
  <?php if ($post['body']): ?><p class="post-text"><?= nl2br(h($post['body'])) ?></p><?php endif; ?>
  <div class="post-chips">
    <span class="chip chip-medium"><?= h(medium_label($post['medium'])) ?></span>
    <span class="chip chip-source"><?= h(source_label($post['source'])) ?></span>
  </div>
  <?php if ($post['image_path']): ?>
  <div class="post-image"><img src="<?= h(UPLOAD_URL.$post['image_path']) ?>" alt="artwork"></div>
  <?php endif; ?>
  <?php if ($post['tags']): ?>
  <div class="post-tags">
    <?php foreach ($post['tags'] as $tag): ?>
      <span class="tag" onclick="location.href='<?= SITE_URL ?>/pages/tag.php?slug=<?= h($tag['slug']) ?>'"><?= h($tag['name']) ?></span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <div class="post-actions">
    <button class="post-action" data-count="<?= $post['like_count'] ?>"
      onclick="toggleLike(this,<?= $post['id'] ?>)">🤍 <?= number_format($post['like_count']) ?></button>
    <button class="post-action">💬 <?= number_format($post['comment_count']) ?></button>
    <button class="post-action" onclick="toggleBookmark(this,<?= $post['id'] ?>)">🔖</button>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($user_posts)): ?>
  <div style="padding:40px;text-align:center;color:var(--text3);">No posts yet.</div>
<?php endif; ?>
</div>

<!-- Portfolio grid -->
<div id="profilePortfolio" style="display:none;">
  <?php if ($me && $me['id'] == $profile['id']): ?>
  <div style="padding:14px 18px;border-bottom:1px solid var(--border);">
    <button class="btn btn-outline btn-sm" onclick="showToast('🖼️','Portfolio upload coming soon')">+ Add to Portfolio</button>
  </div>
  <?php endif; ?>
  <?php if ($portfolio): ?>
  <div class="portfolio-grid">
    <?php foreach ($portfolio as $item): ?>
    <div class="portfolio-item">
      <?php if ($item['image_path']): ?>
        <img src="<?= h(UPLOAD_URL.$item['image_path']) ?>" alt="<?= h($item['title']) ?>">
      <?php else: ?>
        <span style="font-size:32px;color:var(--text3);">🖼️</span>
      <?php endif; ?>
      <div class="portfolio-item-overlay">
        <div class="title"><?= h($item['title']) ?></div>
        <div class="meta"><?= h(medium_label($item['medium'])) ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <div style="padding:40px;text-align:center;color:var(--text3);">No portfolio items yet.</div>
  <?php endif; ?>
</div>

<script>
function showProfileTab(tab) {
  document.getElementById('tabPosts').classList.toggle('active', tab==='posts');
  document.getElementById('tabPortfolio').classList.toggle('active', tab==='portfolio');
  document.getElementById('profilePosts').style.display     = tab==='posts'     ? '' : 'none';
  document.getElementById('profilePortfolio').style.display = tab==='portfolio' ? '' : 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
